#!/usr/bin/env bash
./axiom version