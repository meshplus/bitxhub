 #!/usr/bin/env bash
./axiom --repo $(pwd) start
